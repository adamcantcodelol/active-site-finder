# Active Site Finder — how to publish this for your class

This turns the app into a normal web link (like `your-app-name.streamlit.app`)
that anyone can open in a browser — on a laptop or phone, nothing to
install. You do this setup **once**. Your classmates just click the link.

Total time: about 10 minutes. No terminal, no coding, no installing
anything on your computer — everything below happens on websites.

---

## Step 1 — Create a free GitHub account

GitHub is just a place to store the app's files online so the hosting
service can read them.

1. Go to https://github.com/signup
2. Enter an email, password, and username. Follow the prompts.
3. Verify your email if asked.

If you already have a GitHub account, skip to Step 2.

---

## Step 2 — Create a new repository (a folder for the app's files)

1. Once logged in, go to https://github.com/new
2. Under "Repository name," type: `active-site-finder`
3. Leave it set to **Public**.
4. Check the box **"Add a README file"**.
5. Click the green **"Create repository"** button.

---

## Step 3 — Upload the app's files

1. On your new repository's page, click **"Add file"** → **"Upload files"**
   (top right area of the file list).
2. From the folder you downloaded and unzipped, drag these 4 files
   directly into the browser window:
   - `app.py`
   - `foldseek_client.py`
   - `active_site.py`
   - `requirements.txt`
3. Scroll down and click the green **"Commit changes"** button.

You should now see all 4 files listed on your repository's main page.

---

## Step 4 — Deploy it on Streamlit Community Cloud

This is the free hosting service that actually runs the app 24/7 and
gives you a shareable link.

1. Go to https://share.streamlit.io
2. Click **"Sign in"** and choose **"Continue with GitHub."** Authorize it
   when GitHub asks.
3. Click **"Create app"** (top right).
4. Choose **"Deploy a public app from GitHub."**
5. Fill in the form:
   - **Repository:** pick `your-username/active-site-finder`
   - **Branch:** `main`
   - **Main file path:** `app.py`
6. Optional but recommended: under "App URL," pick a custom, memorable
   name — e.g. `bio101-active-site` — so your link reads
   `bio101-active-site.streamlit.app`.
7. Click **"Deploy."**

The first deploy takes a few minutes while it installs everything. When
it's done, you'll land on your live app with a real public URL.

---

## Step 5 — Share the link

Copy the URL from your browser's address bar (something like
`https://bio101-active-site.streamlit.app`) and send it to your class —
email, Slack, whatever. Anyone with the link can open it and use the app
immediately, no account or install needed on their end.

---

## A few things worth knowing

- **It may take ~30 seconds to "wake up"** the first time someone opens
  it after a period of no use — free hosting puts idle apps to sleep.
  This is normal, not broken; the page will show a "waking up" message.
- **If you ever edit the code**, just upload the new version of the file
  to your GitHub repository (same "Add file → Upload files" steps) — the
  live app updates itself automatically within a minute or two.
- **It's genuinely free** for this kind of use (public app, moderate
  traffic) — no credit card required anywhere in this process.
- If Streamlit ever changes this flow, the official up-to-date steps are
  always at https://docs.streamlit.io/deploy/streamlit-community-cloud

---

## What the app does (for your class)

Type in a 4-character PDB ID (e.g. `4HHB`). The app:
1. Finds proteins with a similar 3D shape using Foldseek, and reports how
   similar (RMSD, TM-score).
2. Predicts the active site of your protein by checking which residues
   in its similar proteins are known to touch a bound drug/cofactor, then
   mapping those positions onto your protein — this works even for a
   protein nobody has studied yet, since the evidence comes from its
   relatives.
3. Shows your protein in 3D with the predicted active site highlighted.

### Limitations worth mentioning in class
- Needs the query protein to have structural relatives with known,
  ligand-bound structures in the PDB — a truly novel fold with no
  relatives will report no active-site prediction rather than guess.
- Residue-number matching across proteins is an approximation (assumes
  standard sequential numbering) — treat predictions as a strong lead to
  verify, not a certainty.
